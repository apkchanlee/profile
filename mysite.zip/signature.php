<?php include 'style.php' ?>

<html>
<head><title>Signature</title></head>
<body>

<div class="container"><br>Thanks and Regards<br><br>

<table style="width:auto;border:0;border-collapse:collapse;font:15px/1.2em sans-serif;"> 
<tbody> 
<tr> <td style="font:15px/1.2em sans-serif;padding:0px 0px 10px 0px;vertical-align:top;border-bottom:2px solid #B33D3D;" colspan="3"> 
<div style=""> <div style="font-size: 18px;font-weight:bold;text-align:left;"> Chandru V</div> </div>
<div style="display:inline-block"> <div style="text-align:left;"> MCA Student<span style="white-space:pre">, 
</span></div> </div><div style="display:inline-block"> <div style="text-align:left;"> University of Madras<span style="white-space:pre"></span></div> 
</div></td> </tr> <tr> <td style="font:15px/1.2em sans-serif;padding:0px 10px 0px 0px;vertical-align:top;"> 
<div> <div style="margin:8px 0;width:69px;">
<img src="img/c.png" style="width:100%"><div onmousedown="xresize.start(event)"></div></div> </div></td> 
<td style="font:15px/1.2em sans-serif;padding:0px 0px 0px 0px;vertical-align:top;"> <div> <div style="margin:8px 0;"> 
<table style="width:auto;border:0;border-collapse:collapse;font:15px/1.2em sans-serif;"> 
<tbody>
            <tr> <td class="td_sign bold">Email:</td> 
                <td class="td_sign"><a href="mailto:apkchanlee@gmail.com" style="color:#0066ff">apkchanlee@gmail.com</a></td> 
            </tr>
            <tr> <td class="td_sign bold">Mobile:</td> 
                <td class="td_sign"><a href="tel:+918667356341">+91 8667356341</a></td> 
            </tr>
            <tr> <td class="td_sign bold">Profession:</td> 
                <td class="td_sign"><a href="https://play.google.com/store/apps/dev?id=9182865619697434101">Android and Web Developer</a></td> 
            </tr>
            <tr> <td class="td_sign bold">Website:</td> 
                <td class="td_sign"> <a href="https://www.chandru.tech" style="color:#0066ff">https://www.chandru.tech</a> </td> 
            </tr> </tbody></table> </div> </div></td> 
<td style="font:15px/1.2em sans-serif;padding:0px 0px 0px 0px;vertical-align:top;"> </td> </tr> 
<tr> <td style="font:15px/1.2em sans-serif;padding:0px 0px 0px 0px;vertical-align:top;" colspan="3"> 

<div> <div style="margin:8px 0;text-align:left;"> 

<a href="https://facebook.com/apkchanlee" style=" display:inline-block;padding-right:5px; ">
<img alt="" height="24" width="24" src="img/facebook.png"></a> 

<a href="https://twitter.com/apkchanlee" style=" display:inline-block;padding-right:5px; ">
<img alt="" height="24" width="24" src="img/twitter.png"></a> 

<a href="https://www.instagram.com/apkchanlee" style=" display:inline-block;padding-right:5px; ">
<img alt="" height="24" width="24" src="img/instagram.png"></a> 

<a href="https://www.linkedin.com/in/apkchanlee" style=" display:inline-block;padding-right:5px; ">
<img alt="" height="24" width="24" src="img/linkedin.png"></a> 

<a href="https://github.com/apkchanlee" style=" display:inline-block;padding-right:5px; ">
<img alt="" height="24" width="24" src="img/github.png"></a> 
</div> </div></td> </tr> </tbody></table> <div> </div> <div> </div> </div> </body></html>