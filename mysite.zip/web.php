<html><head><title> Resume </title></head>
<style>
.fab{
	background: #03A9F4;
	width: 60px;
	height: 60px;
	border-radius: 50%;
	text-align:center;
	color: #FFF;
	box-shadow:0px 0px 3px rgba(0,0,0,0.5),3px 3px 3px rgba(0,0,0,0.25);
	position: fixed;
	bottom: 40px;
	right: 40px;
	font-size: 2.3em;
	display: inline-block;
	cursor: default;
}</style>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

<body>
<iframe src="https://drive.google.com/file/d/1pKeQF8MvDiO3f7GLljNaKlwvMVGXXuPr/preview" width="100%" height="99%"></iframe>

    <a href="https://www.chandru.tech/Chandru%20Resume.pdf" download>
    <div class="fab" id="masterfab">
        <span><i class="fa fa-download" style="margin:8px" aria-hidden="true"></i></span>
    </div>
    </a>

</body></html>